"""Run the EasyInstall command"""

if __name__ == '__main__':
    from setuptools.command.easy_install import main
    main()
